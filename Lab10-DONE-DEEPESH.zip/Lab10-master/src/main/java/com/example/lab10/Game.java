package com.example.lab10;public class Game {
}
